import React, { useState, ChangeEvent, KeyboardEvent, useMemo } from 'react';

interface Person {
  id: string;
  name: string;
}

interface Dish {
  id: string;
  name: string;
  price: number;
  sharedBy: string[]; // Array of Person IDs
}

interface Tax {
  id: string;
  name?: string;
  rate: number; // Percentage, e.g., 10 for 10%
}

// Helper function to generate unique IDs
const generateId = () => crypto.randomUUID();

// Helper function to format currency (optional, but good practice)
const formatCurrency = (amount: number): string => {
  return amount.toFixed(2);
};

export default function BillSplitterApp() {
  const [people, setPeople] = useState<Person[]>([]);
  const [dishes, setDishes] = useState<Dish[]>([]);
  const [taxes, setTaxes] = useState<Tax[]>([]);

  const [newPersonName, setNewPersonName] = useState('');
  const [newDishName, setNewDishName] = useState('');
  const [newDishPrice, setNewDishPrice] = useState('');
  const [newTaxName, setNewTaxName] = useState('');
  const [newTaxRate, setNewTaxRate] = useState('');

  // --- People Management ---
  const handleAddPerson = () => {
    if (newPersonName.trim()) {
      setPeople([...people, { id: generateId(), name: newPersonName.trim() }]);
      setNewPersonName('');
    }
  };

  const handleRemovePerson = (id: string) => {
    setPeople(people.filter(p => p.id !== id));
    // Also remove the person from any dishes they were sharing
    setDishes(dishes.map(dish => ({
      ...dish,
      sharedBy: dish.sharedBy.filter(personId => personId !== id),
    })));
  };

  const handlePersonNameKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleAddPerson();
    }
  };

  // --- Dish Management ---
  const handleAddDish = () => {
    const price = parseFloat(newDishPrice);
    if (newDishName.trim() && !isNaN(price) && price >= 0) {
      setDishes([...dishes, { id: generateId(), name: newDishName.trim(), price, sharedBy: [] }]);
      setNewDishName('');
      setNewDishPrice('');
    }
  };

  const handleRemoveDish = (id: string) => {
    setDishes(dishes.filter(d => d.id !== id));
  };

  const handleDishKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleAddDish();
    }
  };

  const handleToggleDishPerson = (dishId: string, personId: string) => {
    setDishes(dishes.map(dish => {
      if (dish.id === dishId) {
        const isSharing = dish.sharedBy.includes(personId);
        return {
          ...dish,
          sharedBy: isSharing
            ? dish.sharedBy.filter(id => id !== personId)
            : [...dish.sharedBy, personId],
        };
      }
      return dish;
    }));
  };

  // --- Tax Management ---
  const handleAddTax = () => {
    const rate = parseFloat(newTaxRate);
    if (!isNaN(rate) && rate >= 0) {
      setTaxes([...taxes, { id: generateId(), name: newTaxName.trim() || undefined, rate }]);
      setNewTaxName('');
      setNewTaxRate('');
    }
  };

  const handleRemoveTax = (id: string) => {
    setTaxes(taxes.filter(t => t.id !== id));
  };

    const handleTaxKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleAddTax();
    }
  };

  // --- Calculations ---
  const calculationResults = useMemo(() => {
    const subtotal = dishes.reduce((sum, dish) => sum + dish.price, 0);

    let totalTaxes = 0;
    let runningTotal = subtotal;
    const taxBreakdown: { id: string; name?: string; amount: number }[] = [];

    taxes.forEach(tax => {
      const taxAmount = runningTotal * (tax.rate / 100);
      taxBreakdown.push({ id: tax.id, name: tax.name, amount: taxAmount });
      totalTaxes += taxAmount;
      runningTotal += taxAmount; // Apply tax sequentially
    });

    const grandTotal = subtotal + totalTaxes;

    const personTotals: { [personId: string]: { name: string; amount: number } } = {};

    people.forEach(person => {
        let personSubtotal = 0;
        dishes.forEach(dish => {
            if (dish.sharedBy.includes(person.id)) {
                // Divide dish price equally among sharers
                personSubtotal += dish.price / (dish.sharedBy.length || 1);
            }
        });

        // Distribute total taxes proportionally based on each person's subtotal share
        const personTaxShare = subtotal > 0 ? (personSubtotal / subtotal) * totalTaxes : 0;
        const personTotalAmount = personSubtotal + personTaxShare;

        personTotals[person.id] = { name: person.name, amount: personTotalAmount };
    });


    // Verify total matches sum of individual shares (handle potential float precision issues)
    const sumOfPersonTotals = Object.values(personTotals).reduce((sum, p) => sum + p.amount, 0);
    const precisionDifference = Math.abs(grandTotal - sumOfPersonTotals);
    if (precisionDifference > 0.001 && grandTotal > 0) { // Allow tiny difference
        console.warn("Calculation mismatch:", grandTotal, sumOfPersonTotals);
        // Basic reconciliation: Distribute difference proportionally (or assign to first person)
        if (people.length > 0 && personTotals[people[0].id]) {
           personTotals[people[0].id].amount += (grandTotal - sumOfPersonTotals);
        }
    }


    return {
      subtotal,
      totalTaxes,
      grandTotal,
      personTotals,
      taxBreakdown,
    };
  }, [dishes, people, taxes]);

  return (
    <div className="min-h-screen bg-gray-100 p-4 md:p-8">
      <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-lg p-6">
        <h1 className="text-3xl font-bold text-center text-gray-800 mb-8">Bill Splitter</h1>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">

          {/* People Section */}
          <div className="space-y-4 p-4 border border-gray-200 rounded-lg bg-gray-50">
            <h2 className="text-xl font-semibold text-gray-700 mb-3">People</h2>
            <div className="flex space-x-2">
              <input
                type="text"
                value={newPersonName}
                onChange={(e: ChangeEvent<HTMLInputElement>) => setNewPersonName(e.target.value)}
                onKeyDown={handlePersonNameKeyDown}
                placeholder="Enter person's name"
                className="flex-grow p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <button
                onClick={handleAddPerson}
                className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-1"
              >
                Add
              </button>
            </div>
            <ul className="space-y-2">
              {people.map(person => (
                <li key={person.id} className="flex justify-between items-center p-2 bg-white border rounded">
                  <span className="text-gray-700">{person.name}</span>
                  <button
                    onClick={() => handleRemovePerson(person.id)}
                    className="text-red-500 hover:text-red-700 text-sm font-medium focus:outline-none"
                  >
                    Remove
                  </button>
                </li>
              ))}
              {people.length === 0 && <p className="text-sm text-gray-500 italic">No people added yet.</p>}
            </ul>
          </div>

          {/* Taxes Section */}
           <div className="space-y-4 p-4 border border-gray-200 rounded-lg bg-gray-50">
            <h2 className="text-xl font-semibold text-gray-700 mb-3">Taxes / Fees</h2>
             <div className="grid grid-cols-3 gap-2">
               <input
                type="text"
                value={newTaxName}
                onChange={(e: ChangeEvent<HTMLInputElement>) => setNewTaxName(e.target.value)}
                 onKeyDown={handleTaxKeyDown}
                placeholder="Tax Name (Optional)"
                className="col-span-1 p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <input
                type="number"
                value={newTaxRate}
                onChange={(e: ChangeEvent<HTMLInputElement>) => setNewTaxRate(e.target.value)}
                onKeyDown={handleTaxKeyDown}
                placeholder="Rate (%)"
                min="0"
                step="0.01"
                className="col-span-1 p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <button
                onClick={handleAddTax}
                className="col-span-1 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-1"
              >
                Add
              </button>
            </div>
            <ul className="space-y-2">
              {taxes.map(tax => (
                <li key={tax.id} className="flex justify-between items-center p-2 bg-white border rounded">
                  <span className="text-gray-700">
                    {tax.name ? `${tax.name} (${tax.rate}%)` : `${tax.rate}%`}
                  </span>
                   <button
                    onClick={() => handleRemoveTax(tax.id)}
                    className="text-red-500 hover:text-red-700 text-sm font-medium focus:outline-none"
                  >
                    Remove
                  </button>
                </li>
              ))}
               {taxes.length === 0 && <p className="text-sm text-gray-500 italic">No taxes or fees added yet.</p>}
            </ul>
          </div>
        </div>


        {/* Dishes Section */}
        <div className="mb-8 p-4 border border-gray-200 rounded-lg bg-gray-50">
          <h2 className="text-xl font-semibold text-gray-700 mb-3">Dishes</h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 mb-4">
             <input
                type="text"
                value={newDishName}
                onChange={(e: ChangeEvent<HTMLInputElement>) => setNewDishName(e.target.value)}
                onKeyDown={handleDishKeyDown}
                placeholder="Dish Name"
                className="p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <input
                type="number"
                value={newDishPrice}
                onChange={(e: ChangeEvent<HTMLInputElement>) => setNewDishPrice(e.target.value)}
                onKeyDown={handleDishKeyDown}
                placeholder="Price"
                min="0"
                step="0.01"
                className="p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
             <button
                onClick={handleAddDish}
                className="sm:col-span-1 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-1"
              >
                Add Dish
              </button>
          </div>

           <div className="space-y-3">
            {dishes.map(dish => (
              <div key={dish.id} className="p-3 bg-white border rounded-md shadow-sm">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <p className="font-medium text-gray-800">{dish.name}</p>
                    <p className="text-sm text-gray-600">${formatCurrency(dish.price)}</p>
                  </div>
                   <button
                    onClick={() => handleRemoveDish(dish.id)}
                    className="text-red-500 hover:text-red-700 text-xs font-medium focus:outline-none self-start pt-1"
                  >
                    Remove
                  </button>
                </div>
                 <div className="mt-2 pt-2 border-t border-gray-100">
                    <p className="text-sm font-medium text-gray-600 mb-1">Shared by:</p>
                    {people.length > 0 ? (
                        <div className="flex flex-wrap gap-1">
                            {people.map(person => (
                            <button
                                key={person.id}
                                onClick={() => handleToggleDishPerson(dish.id, person.id)}
                                className={`px-2 py-0.5 rounded-full text-xs border
                                ${dish.sharedBy.includes(person.id)
                                    ? 'bg-blue-500 text-white border-blue-500'
                                    : 'bg-gray-100 text-gray-700 border-gray-300 hover:bg-gray-200'
                                }`}
                            >
                                {person.name}
                            </button>
                            ))}
                        </div>
                    ) : (
                        <p className="text-xs text-gray-500 italic">Add people to assign shares.</p>
                    )}
                 </div>
              </div>
            ))}
            {dishes.length === 0 && <p className="text-sm text-gray-500 italic text-center py-4">No dishes added yet.</p>}
          </div>
        </div>

        {/* Summary Section */}
        <div className="p-4 border border-gray-200 rounded-lg bg-gray-50">
            <h2 className="text-xl font-semibold text-gray-700 mb-4">Summary</h2>

             <div className="space-y-2 mb-6 text-gray-700">
                 <div className="flex justify-between">
                    <span>Subtotal:</span>
                    <span>${formatCurrency(calculationResults.subtotal)}</span>
                 </div>
                 {calculationResults.taxBreakdown.map(tax => (
                     <div key={tax.id} className="flex justify-between text-sm text-gray-600">
                         <span>{tax.name || 'Tax/Fee'}:</span>
                         <span>+ ${formatCurrency(tax.amount)}</span>
                     </div>
                 ))}
                  <div className="flex justify-between pt-2 border-t border-gray-300 font-semibold">
                    <span>Grand Total:</span>
                    <span>${formatCurrency(calculationResults.grandTotal)}</span>
                 </div>
             </div>

            <h3 className="text-lg font-semibold text-gray-700 mb-3 pt-4 border-t border-gray-300">Amount Per Person:</h3>
             {people.length > 0 ? (
                 <ul className="space-y-2">
                 {people.map(person => (
                     <li key={person.id} className="flex justify-between items-center p-2 bg-white border rounded">
                         <span className="text-gray-800">{person.name}:</span>
                         <span className="font-medium text-blue-600">
                             ${formatCurrency(calculationResults.personTotals[person.id]?.amount ?? 0)}
                         </span>
                     </li>
                 ))}
                 </ul>
             ) : (
                <p className="text-sm text-gray-500 italic">Add people and assign dishes to see individual totals.</p>
             )}

        </div>

      </div>
    </div>
  );
}